package com.example.yousef;

import android.os.Build;

import androidx.annotation.RequiresApi;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Objects;

/**
 * Subject: Meal Rating
 * By: Yousef Emadi
 * Date: 20-SEP-2021
 */

public class FoodRating implements Comparable, Serializable {

    String mealName;
    float rating;

    public FoodRating() {
    }

    public FoodRating(String mealName, float rating) {
        this.mealName = mealName;
        this.rating = rating;
    }

    public String getMealName() {
        return mealName;
    }

    public void setMealName(String mealName) {
        this.mealName = mealName;
    }

    public float getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        FoodRating that = (FoodRating) o;
        return Float.compare(that.rating, rating) == 0 && mealName.equals(that.mealName);
    }


    @Override
    public int hashCode() {
        return Objects.hash(mealName, rating);
    }

    @Override
    public String toString() {
        return mealName + ", Rating: " + rating + "\n";
    }


    @Override
    public int compareTo(Object o) {
        FoodRating otherObject = (FoodRating) o;
        return mealName.compareTo(otherObject.getMealName());
    }

}
