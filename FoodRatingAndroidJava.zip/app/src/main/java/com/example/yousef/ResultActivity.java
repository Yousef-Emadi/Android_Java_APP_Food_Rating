package com.example.yousef;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;

public class ResultActivity extends AppCompatActivity implements View.OnClickListener {


    TextView txtResult;
    EditText editTxtName;
    Button btnBack;
    RadioGroup radioGroup;
    int selectedRadioBtn;
    ArrayList<FoodRating> listOfMealFoodRating;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        initialize();
    }

    private void initialize() {

        txtResult = findViewById(R.id.textResult);
        editTxtName = findViewById(R.id.editTextName);

        radioGroup = findViewById(R.id.radioGroup);

        btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(this);

        Intent intent = getIntent();
        Bundle bundle = intent.getBundleExtra("intentExtra");
        Serializable bundledList = bundle.getSerializable("bundleExtra");

        listOfMealFoodRating = (ArrayList<FoodRating>) bundledList;

        // Default state of the list
        showAll();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnBack:
                doBack();
                break;
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    public void runMe(View view) {
        selectedRadioBtn = radioGroup.getCheckedRadioButtonId();

        switch (selectedRadioBtn) {
            case R.id.radioButtonHalfstar:
                filterRating(0.5F);
                break;
            case R.id.radioButton1star:
                filterRating(1);
                break;
            case R.id.radioButton1andHalfstar:
                filterRating(1.5F);
                break;
            case R.id.radioButton2star:
                filterRating(2);
                break;
            case R.id.radioButton2andHalfstar:
                filterRating(2.5F);
                break;
            case R.id.radioButton3star:
                filterRating(3);
                break;
            case R.id.radioButtonNameASC:
                sortBYNameASC();
                break;
            case R.id.radioButtonNameDESC:
                sortBYNameDESC();
                break;

        }
    }

    public void filterRating(float stars) {
        String str = "";
        for (FoodRating oneFoodRating : listOfMealFoodRating) {
            if (oneFoodRating.rating == stars) {
                str = str + oneFoodRating.toString();
            }
        }
        txtResult.setText(str);
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    private void sortBYNameDESC() {
        listOfMealFoodRating.sort(Comparator.comparing(FoodRating::getMealName).reversed());
        listMaker(listOfMealFoodRating);
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    private void sortBYNameASC() {
        listOfMealFoodRating.sort(Comparator.comparing(FoodRating::getMealName));
        listMaker(listOfMealFoodRating);
    }

    public void showAll() {
        listMaker(listOfMealFoodRating);
    }

    public void listMaker(ArrayList<FoodRating> list) {
        String str = "";
        for (FoodRating oneFoodRating : list) {
            str = str + oneFoodRating.toString();
        }
        txtResult.setText(str);
    }

    public void doBack() {
        String username = editTxtName.getText().toString();

        Intent intent = new Intent();
        intent.putExtra("username", username);
        setResult(RESULT_OK, intent);
        if (username == "") setResult(RESULT_CANCELED, intent);
        finish();
    }
}