package com.example.yousef;
/**
 * Subject: Meal Rating
 * By: Yousef Emadi
 * Date: 20-SEP-2021
 */

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.Spinner;
import android.widget.TextView;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class MainActivity extends AppCompatActivity implements
        View.OnClickListener, AdapterView.OnItemSelectedListener {

    TextView txtHead;
    Spinner spinnerMeal;
    ImageView imageView;
    RatingBar ratingBar;
    Button btnAdd, btnShowAll, btnMeal, btnSalad, btnSaveToFile, btnLoadFromFile;

    String[] listMeal = {"Salmon", "Poutine", "Sushi", "Tacos"};
    int[] mealPicture = {R.drawable.salmon, R.drawable.poutine, R.drawable.sushi, R.drawable.tacos};

    String[] listSalad = {"Chicken Salad", "Montreal", "Green Salad"};
    int[] saladPicture = {R.drawable.chicken, R.drawable.montreal, R.drawable.green};

    ArrayList<FoodRating> listOfMealFoodRating;
    ArrayAdapter<String> mealAdapter;
    final static int REQUEST_NAME = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initialize();
    }

    private void initialize() {
        listOfMealFoodRating = new ArrayList<>();

        // layout elements
        txtHead = findViewById(R.id.textViewHead);
        imageView = findViewById(R.id.imageView);
        ratingBar = findViewById(R.id.ratingBar);


        btnAdd = findViewById(R.id.btnAdd);
        btnAdd.setOnClickListener(this);

        btnShowAll = findViewById(R.id.btnShowAll);
        btnShowAll.setOnClickListener(this);

        btnMeal = findViewById(R.id.btnMeal);
        btnMeal.setOnClickListener(this);

        btnSalad = findViewById(R.id.btnSalad);
        btnSalad.setOnClickListener(this);

        btnSaveToFile = findViewById(R.id.btnSaveToFile);
        btnSaveToFile.setOnClickListener(this);

        btnLoadFromFile = findViewById(R.id.btnLoadFromFile);
        btnLoadFromFile.setOnClickListener(this);

        spinnerMeal = findViewById(R.id.spinnerMeal);
        spinnerMeal.setOnItemSelectedListener(this);

        //default spinner content is Meals
        doMeal();
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {

            case R.id.btnAdd:
                doRating();
                break;

            case R.id.btnShowAll:
                doShowAllRating();
                break;

            case R.id.btnMeal:
                doMeal();
                break;

            case R.id.btnSalad:
                doSalad();
                break;

            case R.id.btnSaveToFile:
                doSaveToFile();
                break;

            case R.id.btnLoadFromFile:
                doLoadFromFile();
                break;
        }

    }

    private void doLoadFromFile() {
        try {
            File myObj = new File("foods.txt");
            Scanner myReader = new Scanner(myObj);
            System.out.println("\nDatabase content of foods:");
            while (myReader.hasNextLine()) {
                String data1 = myReader.nextLine();
                String array1[] = data1.split(",");

                String field1 = array1[0];
                float field2 = Float.parseFloat(array1[1]);
                FoodRating foodRating = new FoodRating(field1, field2);
                listOfMealFoodRating.add(foodRating);
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("something is wrong with reading foods.txt");
            e.printStackTrace();
        }
    }

    private void doSaveToFile() {
        try {
            FileWriter myWriter = new FileWriter("foods.txt", true);
            String str = "";
            for (FoodRating oneFoodRating : listOfMealFoodRating) {
                str = str + oneFoodRating.toString();
            }
            myWriter.write(str);
            myWriter.close();
            System.out.println("Writing in the foods.txt has been completed.");
        } catch (IOException e) {
            System.out.println("something is wrong with writing foods.txt");
            e.printStackTrace();
        }
    }

    private void doRating() {

        // read current properties and create a new Rating element
        String meal = spinnerMeal.getSelectedItem().toString();
        float rating = ratingBar.getRating();
        FoodRating foodRating = new FoodRating(meal, rating);

        listOfMealFoodRating.add(foodRating);

        // Reset rating bar
        ratingBar.setRating(0);

    }

    private void doShowAllRating() {
        Collections.sort(listOfMealFoodRating);

        Bundle bundle = new Bundle();
        bundle.putSerializable("bundleExtra", listOfMealFoodRating);

        Intent intent = new Intent(this, ResultActivity.class);
        intent.putExtra("intentExtra", bundle);
        startActivityForResult(intent, REQUEST_NAME);
    }

    private void doMeal() {
        makeAdapterForSpinner(listMeal);
    }

    private void doSalad() {
        makeAdapterForSpinner(listSalad);
    }

    public void makeAdapterForSpinner(String[] array) {
        mealAdapter = new ArrayAdapter<>(this,
                R.layout.support_simple_spinner_dropdown_item,
                array);
        spinnerMeal.setAdapter(mealAdapter);
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        if (mealAdapter.getCount() == 3) {
            int image = saladPicture[i];
            imageView.setImageResource(image);
        } else {
            int image = mealPicture[i];
            imageView.setImageResource(image);
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        String receivedResult = null;

        if (requestCode == REQUEST_NAME && resultCode == RESULT_OK) {
            receivedResult = data.getStringExtra("username");
            txtHead.setText("Thank you " + receivedResult);
        }
    }
}